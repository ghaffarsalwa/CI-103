<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <!-- the head section -->
    <head>
        <title>Welcome to Mariomart</title>
        <link rel="stylesheet" type="text/css"
              href="../styles.css" />
    </head>

    <div id="topBarDiv">
    <img id="topLogo" src="../images/pageImages/Logo.png">
    <div id="logoText">MarioMart</div>
    <a id="logout" href="../login.php">Log out </a>
    </div>
    <!-- the body section -->
    <body>

    <div id="page">
        <div id="header">
            
        </div>
       